package Lab4;

public class Task1 {
	
	// sort by descending order
	public static void selectionSort(int[] array) {
		for (int i = 0; i < (array.length -1); i++) {
			int max= i;
			for (int j = i+1; j < array.length; j++) {
				if (array[j]> array[max]) {
					max= j;
				}
			}
			int temp= array[max];
			array[max]= array[i];
			array[i]= temp;
		}
	}
	
	// sort by descending order
	public static void bubbleSort(int[] array) {
		for (int i = 0; i < (array.length-1); i++) {
			for (int j = 0; j < (array.length-i-1); j++) {
				if (array[j]<array[j+1]) {
					int temp= array[j];
					array[j]= array[j+1];
					array[j+1]= temp;
				}
			}
		}
	}
	
	// sort by descending order
	public static void insertionSort(int[] array) {
		for (int i = 0; i < array.length; i++) {
			int k= array[i];
			int j= i-1;
			
			while (j>= 0 && array[j]< k) {
				array[j+1]= array[j];
				j= j-1;
			}
			
			array[j+1]= k;
		}
	}
	
	public static void printArr(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+ " ");
		}
	}
	
	public static void main(String[] args) {
		int arr[] = { 64, 25, 12, 22, 11 };
		System.out.println("Selection Sort: ");
		selectionSort(arr);
		printArr(arr);
		
		int arr1[] = { 64, 72, 69, 22, 11 };
		System.out.println("\nBubble Sort: ");
		bubbleSort(arr1);
		printArr(arr1);
		
		int arr2[] = { 57, 72, 69, 81, 23 };
		System.out.println("\nInsertion Sort: ");
		insertionSort(arr2);
		printArr(arr2);
	}
}
