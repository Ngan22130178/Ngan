package Lab4;

import java.util.Random;

public class QuickSort {
	//Task 2.2
	// sort by ascending order
	void quickSort(int arr[], int low, int high) {
        if (low < high) {

            int pi = partition(arr, low, high);

            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

	
	//select pivot element based on the median of three strategy
	
	
	// select pivot element based on the first element in the array
	int partition(int arr[], int low, int high) {
        int pivot = arr[low];
        int i = (high +1); 
        for (int j = high; j > low; j--) {

            
            if (arr[j] > pivot) {
                i--;

                
                int temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }

        int temp = arr[i - 1];
        arr[i - 1] = arr[low];
        arr[low] = temp;

        return i - 1;
    }


/*	// select pivot element based on the last element in the array
	    int partition(int arr[], int low, int high) {
	        int pivot = arr[high];
	        int i = (low - 1); 
	        for (int j = low; j < high; j++) {

	            
	            if (arr[j] < pivot) {
	                i++;

	                
	                int temp = arr[i];
	                arr[i] = arr[j];
	                arr[j] = temp;
	            }
	        }

	        int temp = arr[i + 1];
	        arr[i + 1] = arr[high];
	        arr[high] = temp;

	        return i + 1;
	    }
*/
	 // select pivot element based on choosing a randomly element in the array


	    static void printArray(int arr[]) {
	        int n = arr.length;
	        for (int i = 0; i < n; ++i)
	            System.out.print(arr[i] + " ");
	        System.out.println();
	    }

	    public static void main(String args[]) {
	        int arr[] = { 10, 80, 30, 90, 40, 50, 70 };
	        int n = arr.length;
	        
	        System.out.println("Mảng ban đầu:");
	        printArray(arr);

	        QuickSort ob = new QuickSort();
	        ob.quickSort(arr, 0, n - 1);

	        System.out.println("Mảng sau khi sắp xếp:");
	        printArray(arr);
	    }
}
	 


