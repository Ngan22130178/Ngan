package Lab4;


public class Task2_1 {
//Task 2.1
	public static void mergeSort(int[] array, int l, int r) {
		int mid;
		int len= array.length;
		
		if(len <=0) 
			System.out.println("Chuoi khong co phan tu");
		if(len ==1) 
			System.out.println(array[0]);
		else {
			mid= (l+r)/2;
			
		//size arrays
		int n1= mid- l+1;
		int n2= r- mid;
		
		//new arrays
		int L[]= new int[n1];
		for (int i = 0; i < L.length; i++) 
			L[i]= array[l+i];
			
		int R[]= new int[n2];
		for (int j = 0; j < R.length; j++) 
			R[j]= array[mid+j+1];
			
		int i=0;
		int j=0;
		int k= l;
		while (i< n1 &&j< n2) {
			if (L[i] >= R[j]){
				array[k]= L[i];
				i++;
			}
			else  {
				array[k]= R[j];
				j++;
			}
			k++;
		}
		
		while (i< n1) {
			array[k]= L[i];
			i++;
			k++;
		}
		
		while (j< n2) {
			array[k]= R[j];
			j++;
			k++;
		}
		}
		
		if (l<r) {
			int m= l+ (r-l)/2;
			
			mergeSort(array, l, m);
			mergeSort(array, m+1, r);
		}
	}
	
	 static void printArray(int arr[])
	    {
	        int n = arr.length;
	        for (int i = 0; i < n; ++i)
	            System.out.print(arr[i] + " ");
	        System.out.println();
	    }
	 
	    public static void main(String args[])
	    {
	        int arr[] = { 12, 11, 13, 5, 6, 7 };
	 
	        System.out.println("Given array is");
	        printArray(arr);
	 
	       
	        mergeSort(arr, 0, arr.length-1);
	        System.out.println("\nSorted array is");
	        printArray(arr);
	        
	        
	    }
	

}
