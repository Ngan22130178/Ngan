/**
 * 
 */
/**
 * @author TRUC DAO
 *
 */
module Lab5 {
}